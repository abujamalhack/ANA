import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:voice_chat_app/core/theme/app_theme.dart';
import 'package:voice_chat_app/firebase_options.dart';
import 'package:voice_chat_app/injection_container.dart';
import 'package:voice_chat_app/presentation/cubits/auth_cubit.dart';
import 'package:voice_chat_app/presentation/cubits/room_cubit.dart';
import 'package:voice_chat_app/presentation/cubits/audio_cubit.dart';
import 'package:voice_chat_app/presentation/screens/auth/login_screen.dart';
import 'package:voice_chat_app/presentation/screens/auth/register_screen.dart';
import 'package:voice_chat_app/presentation/screens/home_screen.dart';
import 'package:voice_chat_app/presentation/screens/create_room_screen.dart';
import 'package:voice_chat_app/presentation/screens/room_screen.dart';
import 'package:voice_chat_app/presentation/screens/profile_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Crashlytics setup
  FlutterError.onError = FirebaseCrashlytics.instance.recordFlutterError;

  // Dependency injection
  await initInjection();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => sl<AuthCubit>()),
        BlocProvider(create: (_) => sl<RoomCubit>()),
        BlocProvider(create: (_) => sl<AudioCubit>()),
      ],
      child: MaterialApp(
        title: 'Voice Chat',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        initialRoute: '/',
        routes: {
          '/': (context) => const AuthWrapper(),
          '/register': (context) => const RegisterScreen(),
          '/home': (context) => const HomeScreen(),
          '/create-room': (context) => const CreateRoomScreen(),
          '/profile': (context) => const ProfileScreen(),
        },
        onGenerateRoute: (settings) {
          if (settings.name == '/room') {
            final roomId = settings.arguments as String;
            return MaterialPageRoute(
              builder: (_) => RoomScreen(roomId: roomId),
            );
          }
          return null;
        },
      ),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthCubit, AuthState>(
      builder: (context, state) {
        if (state is AuthAuthenticated) {
          return const HomeScreen();
        } else if (state is AuthUnauthenticated) {
          return const LoginScreen();
        } else {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
      },
    );
  }
}