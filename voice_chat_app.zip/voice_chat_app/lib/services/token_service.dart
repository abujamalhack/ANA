import 'package:cloud_functions/cloud_functions.dart';
import 'package:voice_chat_app/core/constants/app_constants.dart';
import 'package:voice_chat_app/core/utils/logger.dart';

class TokenService {
  final FirebaseFunctions _functions = FirebaseFunctions.instance;

  Future<String?> fetchAgoraToken(String channelName, int uid) async {
    try {
      final callable = _functions.httpsCallable('generateToken');
      final result = await callable.call({
        'channelName': channelName,
        'uid': uid,
      });
      return result.data['token'];
    } on FirebaseFunctionsException catch (e) {
      Logger.logError('Firebase Functions error: ${e.message}', error: e);
      return null;
    } catch (e) {
      Logger.logError('Failed to fetch Agora token', error: e);
      return null;
    }
  }
}