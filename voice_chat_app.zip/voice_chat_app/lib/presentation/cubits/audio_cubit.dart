import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:voice_chat_app/core/constants/app_constants.dart';
import 'package:voice_chat_app/data/services/agora_service.dart';
import 'package:voice_chat_app/services/token_service.dart';

part 'audio_state.dart';

class AudioCubit extends Cubit<AudioState> {
  final TokenService _tokenService = TokenService();
  StreamSubscription? _userJoinedSub;
  StreamSubscription? _userLeftSub;
  StreamSubscription? _errorSub;
  StreamSubscription? _connectionSub;
  Timer? _tokenRenewTimer;

  AudioCubit() : super(AudioInitial());

  // ====================
  // الدالة المعدلة: إضافة retry mechanism
  // ====================
  Future<void> initializeAndJoinChannel(
    String channelName,
    int uid, {
    int retryCount = 0,
  }) async {
    emit(AudioConnecting());

    final initSuccess = await AgoraService.initialize(AppConstants.agoraAppId);
    if (!initSuccess) {
      emit(const AudioError('Failed to initialize Agora'));
      return;
    }

    _subscribeToEvents();

    final token = await _tokenService.fetchAgoraToken(channelName, uid);
    if (token == null) {
      emit(const AudioError('Failed to get token'));
      return;
    }

    final joinSuccess = await AgoraService.joinChannel(
      channelName,
      uid,
      token: token,
    );
    if (!joinSuccess) {
      if (retryCount < AppConstants.maxRetries) {
        // تأخير قبل إعادة المحاولة
        await Future.delayed(AppConstants.retryDelay);
        // استدعاء ذاتي مع زيادة retryCount
        return initializeAndJoinChannel(
          channelName,
          uid,
          retryCount: retryCount + 1,
        );
      }
      emit(const AudioError('Failed to join channel'));
      return;
    }

    emit(AudioConnected());

    // جدولة تجديد التوكن (قبل انتهاء صلاحيته بـ 5 دقائق)
    _tokenRenewTimer?.cancel();
    _tokenRenewTimer = Timer(
      Duration(seconds: AppConstants.tokenExpirySeconds - 300),
      () async {
        final newToken = await _tokenService.fetchAgoraToken(channelName, uid);
        if (newToken != null) {
          await AgoraService.renewToken(newToken);
        }
      },
    );
  }

  void _subscribeToEvents() {
    _userJoinedSub?.cancel();
    _userJoinedSub = AgoraService.onUserJoined.listen((remoteUid) {
      emit(AudioUserJoined(remoteUid));
    });

    _userLeftSub?.cancel();
    _userLeftSub = AgoraService.onUserLeft.listen((remoteUid) {
      emit(AudioUserLeft(remoteUid));
    });

    _errorSub?.cancel();
    _errorSub = AgoraService.onError.listen((errorMsg) {
      emit(AudioError(errorMsg));
    });

    _connectionSub?.cancel();
    _connectionSub = AgoraService.onConnectionState.listen((state) {
      emit(AudioConnectionStateChanged(state));
    });
  }

  Future<void> toggleMute(bool muted) async {
    await AgoraService.muteLocalAudio(muted);
    emit(AudioMuteToggled(muted));
  }

  Future<void> leaveChannel() async {
    await AgoraService.leaveChannel();
    _tokenRenewTimer?.cancel();
    emit(AudioDisconnected());
  }

  @override
  Future<void> close() async {
    await _userJoinedSub?.cancel();
    await _userLeftSub?.cancel();
    await _errorSub?.cancel();
    await _connectionSub?.cancel();
    await AgoraService.dispose();
    super.close();
  }
}