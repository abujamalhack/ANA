import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:voice_chat_app/presentation/cubits/auth_cubit.dart';
import 'package:voice_chat_app/presentation/cubits/room_cubit.dart';
import 'package:voice_chat_app/presentation/widgets/room_card.dart';
import 'package:voice_chat_app/presentation/screens/create_room_screen.dart';
import 'package:voice_chat_app/presentation/screens/room_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    context.read<RoomCubit>().loadPublicRooms();
    _scrollController.addListener(() {
      if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 200) {
        context.read<RoomCubit>().loadMore();
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = context.watch<AuthCubit>().state;
    final user = authState is AuthAuthenticated ? authState.user : null;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Voice Chat Rooms'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => context.read<AuthCubit>().logout(),
          ),
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: () => Navigator.pushNamed(context, '/profile'),
          ),
        ],
      ),
      body: BlocBuilder<RoomCubit, RoomState>(
        builder: (context, state) {
          if (state is RoomLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is RoomLoaded) {
            if (state.rooms.isEmpty) {
              return const Center(child: Text('No public rooms available'));
            }
            return ListView.builder(
              controller: _scrollController,
              itemCount: state.rooms.length + 1,
              itemBuilder: (context, index) {
                if (index == state.rooms.length) {
                  if (state is RoomLoadingMore) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  return const SizedBox();
                }
                final room = state.rooms[index];
                return RoomCard(
                  room: room,
                  onTap: () {
                    if (user != null) {
                      context.read<RoomCubit>().joinRoom(room.roomId, user.uid);
                      Navigator.pushNamed(context, '/room', arguments: room.roomId);
                    }
                  },
                );
              },
            );
          } else if (state is RoomLoadingMore) {
            // عرض القائمة مع مؤشر تحميل في الأسفل
            return ListView.builder(
              controller: _scrollController,
              itemCount: state.rooms.length + 1,
              itemBuilder: (context, index) {
                if (index == state.rooms.length) {
                  return const Center(child: CircularProgressIndicator());
                }
                final room = state.rooms[index];
                return RoomCard(
                  room: room,
                  onTap: () {
                    if (user != null) {
                      context.read<RoomCubit>().joinRoom(room.roomId, user.uid);
                      Navigator.pushNamed(context, '/room', arguments: room.roomId);
                    }
                  },
                );
              },
            );
          } else if (state is RoomError) {
            return Center(child: Text('Error: ${state.message}'));
          }
          return const SizedBox.shrink();
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, '/create-room'),
        child: const Icon(Icons.add),
      ),
    );
  }
}