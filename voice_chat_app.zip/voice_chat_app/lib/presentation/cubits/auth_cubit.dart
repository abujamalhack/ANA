import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:voice_chat_app/data/models/user_model.dart';
import 'package:voice_chat_app/data/repositories/auth_repository.dart';
import 'package:voice_chat_app/data/services/notification_service.dart';

part 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  final AuthRepository _authRepository;
  final NotificationService _notificationService;

  AuthCubit(this._authRepository, this._notificationService) : super(AuthInitial()) {
    _authRepository.authState.listen((user) {
      if (user != null) {
        emit(AuthAuthenticated(user));
        _notificationService.initialize(); // Initialize notifications after login
      } else {
        emit(AuthUnauthenticated());
      }
    });
  }

  Future<void> checkAuthStatus() async {
    final user = _authRepository.currentUser;
    if (user != null) {
      emit(AuthAuthenticated(user));
    } else {
      emit(AuthUnauthenticated());
    }
  }

  Future<void> loginWithEmail(String email, String password) async {
    emit(AuthLoading());
    try {
      final user = await _authRepository.loginWithEmail(email, password);
      emit(AuthAuthenticated(user));
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  Future<void> registerWithEmail(String email, String password, String displayName) async {
    emit(AuthLoading());
    try {
      final user = await _authRepository.registerWithEmail(email, password, displayName);
      emit(AuthAuthenticated(user));
    } catch (e) {
      emit(AuthError(e.toString()));
    }
  }

  Future<void> logout() async {
    await _authRepository.logout();
    emit(AuthUnauthenticated());
  }
}