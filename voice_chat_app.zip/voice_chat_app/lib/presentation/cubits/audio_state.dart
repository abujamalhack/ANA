part of 'audio_cubit.dart';

abstract class AudioState extends Equatable {
  const AudioState();
  @override
  List<Object?> get props => [];
}

class AudioInitial extends AudioState {}
class AudioConnecting extends AudioState {}
class AudioConnected extends AudioState {}
class AudioDisconnected extends AudioState {}

class AudioUserJoined extends AudioState {
  final int uid;
  const AudioUserJoined(this.uid);
  @override
  List<Object?> get props => [uid];
}

class AudioUserLeft extends AudioState {
  final int uid;
  const AudioUserLeft(this.uid);
  @override
  List<Object?> get props => [uid];
}

class AudioMuteToggled extends AudioState {
  final bool isMuted;
  const AudioMuteToggled(this.isMuted);
  @override
  List<Object?> get props => [isMuted];
}

class AudioConnectionStateChanged extends AudioState {
  final ConnectionState state;
  const AudioConnectionStateChanged(this.state);
  @override
  List<Object?> get props => [state];
}

class AudioError extends AudioState {
  final String message;
  const AudioError(this.message);
  @override
  List<Object?> get props => [message];
}