part of 'room_cubit.dart';

abstract class RoomState extends Equatable {
  const RoomState();
  @override
  List<Object?> get props => [];
}

class RoomInitial extends RoomState {}
class RoomLoading extends RoomState {}
class RoomLoaded extends RoomState {
  final List<RoomModel> rooms;
  const RoomLoaded(this.rooms);
  @override
  List<Object?> get props => [rooms];
}
class RoomCreating extends RoomState {}
class RoomCreated extends RoomState {
  final String roomId;
  const RoomCreated(this.roomId);
  @override
  List<Object?> get props => [roomId];
}
class RoomDetailLoaded extends RoomState {
  final RoomModel room;
  const RoomDetailLoaded(this.room);
  @override
  List<Object?> get props => [room];
}
class RoomLeft extends RoomState {}
class RoomDeleted extends RoomState {}
class RoomError extends RoomState {
  final String message;
  const RoomError(this.message);
  @override
  List<Object?> get props => [message];
}