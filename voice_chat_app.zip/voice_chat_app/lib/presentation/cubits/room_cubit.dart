import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:voice_chat_app/data/models/room_model.dart';
import 'package:voice_chat_app/data/repositories/room_repository.dart';

part 'room_state.dart';

class RoomCubit extends Cubit<RoomState> {
  final RoomRepository _roomRepository;
  // تم إزالة _rooms لأنه غير مستخدم الآن
  DocumentSnapshot? _lastDocument;
  bool _hasMore = true;
  bool _isLoadingMore = false;

  RoomCubit(this._roomRepository) : super(RoomInitial());

  // ====================
  // الدالة المعدلة: تحميل الغرف العامة مع pagination
  // ====================
  Future<void> loadPublicRooms({bool refresh = false}) async {
    if (refresh) {
      _lastDocument = null;
      _hasMore = true;
      _isLoadingMore = false;
      emit(RoomLoading());
    }
    if (!_hasMore || _isLoadingMore) return;

    _isLoadingMore = true;
    try {
      final result = await _roomRepository.getPublicRoomsPaginated(
        limit: 20,
        startAfter: refresh ? null : _lastDocument,
      );

      _lastDocument = result.lastDoc;
      if (result.rooms.length < 20) _hasMore = false;

      final currentState = state;
      List<RoomModel> newRooms;

      if (refresh || currentState is! RoomLoaded) {
        newRooms = result.rooms;
      } else if (currentState is RoomLoaded) {
        // دمج مع تجنب التكرار
        final existingRooms = currentState.rooms;
        newRooms = [...existingRooms];
        for (final room in result.rooms) {
          if (!newRooms.any((r) => r.roomId == room.roomId)) {
            newRooms.add(room);
          }
        }
      } else {
        newRooms = result.rooms;
      }

      emit(RoomLoaded(newRooms));
    } catch (e) {
      emit(RoomError(e.toString()));
    } finally {
      _isLoadingMore = false;
    }
  }

  // ====================
  // باقي الدوال كما هي (بدون تغيير)
  // ====================
  Future<void> createRoom(RoomModel room) async {
    emit(RoomCreating());
    try {
      final roomId = await _roomRepository.createRoom(room);
      emit(RoomCreated(roomId));
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  Future<void> joinRoom(String roomId, String userId) async {
    try {
      await _roomRepository.joinRoom(roomId, userId);
      loadRoom(roomId);
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  Future<void> leaveRoom(String roomId, String userId) async {
    try {
      await _roomRepository.leaveRoom(roomId, userId);
      if (state is RoomDetailLoaded) emit(RoomLeft());
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  void loadRoom(String roomId) {
    emit(RoomLoading());
    _roomRepository.streamRoom(roomId).listen((room) {
      if (room != null) {
        emit(RoomDetailLoaded(room));
      } else {
        emit(RoomError('Room not found'));
      }
    }).onError((error) => emit(RoomError(error.toString())));
  }

  Future<void> deleteRoom(String roomId) async {
    try {
      await _roomRepository.deleteRoom(roomId);
      emit(RoomDeleted());
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  Future<void> raiseHand(String roomId, String uid) async {
    try {
      await _roomRepository.raiseHand(roomId, uid);
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  Future<void> lowerHand(String roomId, String uid) async {
    try {
      await _roomRepository.lowerHand(roomId, uid);
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  Future<void> muteUser(String roomId, String uid) async {
    try {
      await _roomRepository.muteUser(roomId, uid);
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  Future<void> unmuteUser(String roomId, String uid) async {
    try {
      await _roomRepository.unmuteUser(roomId, uid);
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  Future<void> removeUser(String roomId, String uid) async {
    try {
      await _roomRepository.removeUser(roomId, uid);
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  Future<void> setModerator(String roomId, String uid, bool isModerator) async {
    try {
      await _roomRepository.setModerator(roomId, uid, isModerator);
    } catch (e) {
      emit(RoomError(e.toString()));
    }
  }

  @override
  Future<void> close() {
    return super.close();
  }
}