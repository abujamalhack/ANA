import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:voice_chat_app/data/models/room_model.dart';
import 'package:voice_chat_app/presentation/cubits/auth_cubit.dart';
import 'package:voice_chat_app/presentation/cubits/audio_cubit.dart';
import 'package:voice_chat_app/presentation/cubits/room_cubit.dart';
import 'package:voice_chat_app/presentation/widgets/mic_button.dart';
import 'package:voice_chat_app/presentation/widgets/loading_overlay.dart';

class RoomScreen extends StatefulWidget {
  final String roomId;
  const RoomScreen({super.key, required this.roomId});

  @override
  State<RoomScreen> createState() => _RoomScreenState();
}

class _RoomScreenState extends State<RoomScreen> {
  @override
  void initState() {
    super.initState();
    context.read<RoomCubit>().loadRoom(widget.roomId);
  }

  @override
  void dispose() {
    context.read<AudioCubit>().leaveChannel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = context.watch<AuthCubit>().state;
    final currentUser = authState is AuthAuthenticated ? authState.user : null;
    final currentUid = currentUser?.uid;

    return Scaffold(
      appBar: AppBar(
        title: BlocBuilder<RoomCubit, RoomState>(
          builder: (context, state) {
            if (state is RoomDetailLoaded) return Text(state.room.roomName);
            return const Text('Room');
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.exit_to_app),
            onPressed: () async {
              if (currentUid != null) {
                await context.read<RoomCubit>().leaveRoom(widget.roomId, currentUid);
                if (mounted) Navigator.pop(context);
              }
            },
          ),
        ],
      ),
      body: BlocBuilder<RoomCubit, RoomState>(
        builder: (context, roomState) {
          if (roomState is RoomDetailLoaded) {
            final room = roomState.room;
            final userRole = room.participants[currentUid] ?? UserRole.user;
            final isOwner = userRole == UserRole.owner;
            final isModerator = userRole == UserRole.moderator || isOwner;

            return BlocConsumer<AudioCubit, AudioState>(
              listener: (context, audioState) {
                if (audioState is AudioError) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(audioState.message)),
                  );
                }
              },
              builder: (context, audioState) {
                if (audioState is AudioInitial && currentUid != null) {
                  final uid = currentUid.hashCode.abs();
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    context.read<AudioCubit>().initializeAndJoinChannel(room.roomId, uid);
                  });
                }

                // Order participants: owners first, then moderators, then users with raised hands, then others
                final participantsList = room.participants.keys.toList();
                participantsList.sort((a, b) {
                  final roleA = room.participants[a]!;
                  final roleB = room.participants[b]!;
                  if (roleA == roleB) {
                    final handA = room.raisedHands.contains(a);
                    final handB = room.raisedHands.contains(b);
                    if (handA && !handB) return -1;
                    if (!handA && handB) return 1;
                    return 0;
                  }
                  if (roleA == UserRole.owner) return -1;
                  if (roleB == UserRole.owner) return 1;
                  if (roleA == UserRole.moderator) return -1;
                  if (roleB == UserRole.moderator) return 1;
                  return 0;
                });

                return Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        itemCount: participantsList.length,
                        itemBuilder: (context, index) {
                          final uid = participantsList[index];
                          final role = room.participants[uid]!;
                          final isCurrentUser = uid == currentUid;
                          final isRaisedHand = room.raisedHands.contains(uid);
                          final isMutedByMod = room.mutedUsers.contains(uid);
                          final canMute = isModerator && !isCurrentUser && uid != room.creatorUid;
                          final canRemove = isModerator && !isCurrentUser;
                          final canSetModerator = isOwner && !isCurrentUser && uid != room.creatorUid;

                          return ListTile(
                            key: ValueKey(uid),
                            leading: CircleAvatar(
                              child: Text(uid.substring(0, 1).toUpperCase()),
                            ),
                            title: Text(
                              isCurrentUser ? 'You' : 'User $uid',
                              style: const TextStyle(fontWeight: FontWeight.bold),
                            ),
                            subtitle: Wrap(
                              spacing: 4,
                              children: [
                                if (role == UserRole.owner)
                                  const Chip(label: Text('Owner'), backgroundColor: Colors.amber),
                                if (role == UserRole.moderator)
                                  const Chip(label: Text('Moderator'), backgroundColor: Colors.blue),
                                if (isRaisedHand)
                                  const Chip(label: Text('Hand Raised'), backgroundColor: Colors.green),
                                if (isMutedByMod)
                                  const Chip(label: Text('Muted'), backgroundColor: Colors.red),
                              ],
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (canMute)
                                  IconButton(
                                    icon: Icon(isMutedByMod ? Icons.mic_off : Icons.mic),
                                    onPressed: () {
                                      if (isMutedByMod) {
                                        context.read<RoomCubit>().unmuteUser(widget.roomId, uid);
                                      } else {
                                        context.read<RoomCubit>().muteUser(widget.roomId, uid);
                                      }
                                    },
                                  ),
                                if (canRemove)
                                  IconButton(
                                    icon: const Icon(Icons.remove_circle_outline),
                                    onPressed: () => _showRemoveConfirmation(uid),
                                  ),
                                if (canSetModerator)
                                  IconButton(
                                    icon: Icon(role == UserRole.moderator ? Icons.star : Icons.star_border),
                                    onPressed: () {
                                      context.read<RoomCubit>().setModerator(
                                        widget.roomId,
                                        uid,
                                        role != UserRole.moderator,
                                      );
                                    },
                                  ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          MicButton(
                            onToggle: (muted) {
                              context.read<AudioCubit>().toggleMute(muted);
                            },
                          ),
                          if (userRole != UserRole.owner && userRole != UserRole.moderator)
                            BlocBuilder<RoomCubit, RoomState>(
                              builder: (context, state) {
                                final isHandRaised = state is RoomDetailLoaded
                                    ? state.room.raisedHands.contains(currentUid)
                                    : false;
                                return ElevatedButton(
                                  onPressed: () {
                                    if (isHandRaised) {
                                      context.read<RoomCubit>().lowerHand(widget.roomId, currentUid!);
                                    } else {
                                      context.read<RoomCubit>().raiseHand(widget.roomId, currentUid!);
                                    }
                                  },
                                  child: Text(isHandRaised ? 'Lower Hand' : 'Raise Hand'),
                                );
                              },
                            ),
                          if (isModerator)
                            ElevatedButton(
                              onPressed: () => _showRaisedHandsDialog(room),
                              child: const Text('Raised Hands'),
                            ),
                        ],
                      ),
                    ),
                  ],
                );
              },
            );
          } else if (roomState is RoomLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (roomState is RoomError) {
            return Center(child: Text('Error: ${roomState.message}'));
          } else {
            return const SizedBox.shrink();
          }
        },
      ),
    );
  }

  void _showRemoveConfirmation(String uid) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Remove User'),
        content: const Text('Are you sure you want to remove this user from the room?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              context.read<RoomCubit>().removeUser(widget.roomId, uid);
              Navigator.pop(context);
            },
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }

  void _showRaisedHandsDialog(RoomModel room) {
    final raisedList = room.raisedHands;
    if (raisedList.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No one raised hand')),
      );
      return;
    }
    showModalBottomSheet(
      context: context,
      builder: (_) => ListView(
        children: raisedList.map((uid) {
          return ListTile(
            title: Text('User $uid'),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.mic),
                  onPressed: () {
                    context.read<RoomCubit>().unmuteUser(widget.roomId, uid);
                    context.read<RoomCubit>().lowerHand(widget.roomId, uid);
                    Navigator.pop(context);
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () {
                    context.read<RoomCubit>().lowerHand(widget.roomId, uid);
                    Navigator.pop(context);
                  },
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}