import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:voice_chat_app/presentation/cubits/auth_cubit.dart';
import 'package:voice_chat_app/presentation/widgets/custom_button.dart';
import 'package:voice_chat_app/presentation/widgets/loading_overlay.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  Widget build(BuildContext context) {
    final authState = context.watch<AuthCubit>().state;
    final user = authState is AuthAuthenticated ? authState.user : null;

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: user == null
          ? const Center(child: Text('No user logged in'))
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundImage: user.photoUrl != null
                        ? NetworkImage(user.photoUrl!)
                        : null,
                    child: user.photoUrl == null
                        ? Text(user.displayName?.substring(0, 1).toUpperCase() ?? 'U')
                        : null,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    user.displayName ?? 'No name',
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(user.email),
                  const SizedBox(height: 24),
                  CustomButton(
                    text: 'Edit Profile',
                    onPressed: () {
                      // TODO: implement edit profile
                    },
                  ),
                  const SizedBox(height: 16),
                  CustomButton(
                    text: 'Logout',
                    onPressed: () {
                      context.read<AuthCubit>().logout();
                      Navigator.pop(context);
                    },
                  ),
                ],
              ),
            ),
    );
  }
}