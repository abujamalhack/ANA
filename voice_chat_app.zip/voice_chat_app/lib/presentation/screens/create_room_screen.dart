import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:voice_chat_app/presentation/cubits/auth_cubit.dart';
import 'package:voice_chat_app/presentation/cubits/room_cubit.dart';
import 'package:voice_chat_app/data/models/room_model.dart';
import 'package:voice_chat_app/presentation/widgets/custom_button.dart';
import 'package:voice_chat_app/presentation/widgets/custom_text_field.dart';
import 'package:voice_chat_app/presentation/widgets/loading_overlay.dart';

class CreateRoomScreen extends StatefulWidget {
  const CreateRoomScreen({super.key});

  @override
  State<CreateRoomScreen> createState() => _CreateRoomScreenState();
}

class _CreateRoomScreenState extends State<CreateRoomScreen> {
  final _nameController = TextEditingController();
  bool _isPrivate = false;
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _nameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = (context.read<AuthCubit>().state as AuthAuthenticated).user;

    return Scaffold(
      appBar: AppBar(title: const Text('Create Room')),
      body: BlocConsumer<RoomCubit, RoomState>(
        listener: (context, state) {
          if (state is RoomCreated) {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Room created successfully')),
            );
          } else if (state is RoomError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.message)),
            );
          }
        },
        builder: (context, state) {
          return LoadingOverlay(
            isLoading: state is RoomCreating,
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomTextField(
                      controller: _nameController,
                      label: 'Room Name',
                      validator: (value) =>
                          value == null || value.isEmpty ? 'Please enter room name' : null,
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        const Text('Private Room'),
                        const SizedBox(width: 10),
                        Switch(
                          value: _isPrivate,
                          onChanged: (value) {
                            setState(() {
                              _isPrivate = value;
                            });
                          },
                        ),
                      ],
                    ),
                    if (_isPrivate) ...[
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: _passwordController,
                        label: 'Password',
                        obscureText: true,
                        validator: (value) {
                          if (_isPrivate && (value == null || value.isEmpty)) {
                            return 'Please enter a password';
                          }
                          return null;
                        },
                      ),
                    ],
                    const SizedBox(height: 24),
                    CustomButton(
                      text: 'Create Room',
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          final room = RoomModel(
                            roomId: '',
                            roomName: _nameController.text.trim(),
                            creatorUid: user.uid,
                            isPrivate: _isPrivate,
                            participants: {user.uid: UserRole.owner},
                            raisedHands: [],
                            mutedUsers: [],
                            createdAt: DateTime.now(),
                            password: _isPrivate ? _passwordController.text.trim() : null,
                          );
                          context.read<RoomCubit>().createRoom(room);
                        }
                      },
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}