import 'package:flutter/material.dart';
import 'package:voice_chat_app/data/models/room_model.dart';

class RoomCard extends StatelessWidget {
  final RoomModel room;
  final VoidCallback onTap;

  const RoomCard({super.key, required this.room, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListTile(
        leading: const Icon(Icons.group),
        title: Text(room.roomName),
        subtitle: Text('Participants: ${room.participants.length}'),
        trailing: room.isPrivate ? const Icon(Icons.lock) : null,
        onTap: onTap,
      ),
    );
  }
}