import 'package:flutter/material.dart';

class MicButton extends StatefulWidget {
  final Function(bool) onToggle;
  const MicButton({super.key, required this.onToggle});

  @override
  State<MicButton> createState() => _MicButtonState();
}

class _MicButtonState extends State<MicButton> {
  bool _isMuted = false;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(_isMuted ? Icons.mic_off : Icons.mic),
      iconSize: 40,
      onPressed: () {
        setState(() {
          _isMuted = !_isMuted;
        });
        widget.onToggle(_isMuted);
      },
    );
  }
}