import 'package:get_it/get_it.dart';
import 'package:voice_chat_app/data/repositories/auth_repository.dart';
import 'package:voice_chat_app/data/repositories/room_repository.dart';
import 'package:voice_chat_app/data/services/firebase_service.dart';
import 'package:voice_chat_app/data/services/notification_service.dart';
import 'package:voice_chat_app/presentation/cubits/auth_cubit.dart';
import 'package:voice_chat_app/presentation/cubits/room_cubit.dart';
import 'package:voice_chat_app/presentation/cubits/audio_cubit.dart';
import 'package:voice_chat_app/services/token_service.dart';

final sl = GetIt.instance;

Future<void> initInjection() async {
  // Services
  sl.registerLazySingleton<FirebaseService>(() => FirebaseServiceImpl());
  sl.registerLazySingleton<TokenService>(() => TokenService());
  sl.registerLazySingleton<NotificationService>(() => NotificationService());

  // Repositories
  sl.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(sl<FirebaseService>()),
  );
  sl.registerLazySingleton<RoomRepository>(
    () => RoomRepositoryImpl(sl<FirebaseService>()),
  );

  // Cubits
  sl.registerFactory<AuthCubit>(
    () => AuthCubit(sl<AuthRepository>(), sl<NotificationService>()),
  );
  sl.registerFactory<RoomCubit>(
    () => RoomCubit(sl<RoomRepository>()),
  );
  sl.registerFactory<AudioCubit>(
    () => AudioCubit(),
  );
}