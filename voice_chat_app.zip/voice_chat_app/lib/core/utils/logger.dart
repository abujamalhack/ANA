import 'package:firebase_crashlytics/firebase_crashlytics.dart';

class Logger {
  static void logInfo(String message) {
    print('INFO: $message');
    // Optionally send to Crashlytics as non-fatal
    FirebaseCrashlytics.instance.log('INFO: $message');
  }

  static void logWarning(String message) {
    print('WARNING: $message');
    FirebaseCrashlytics.instance.log('WARNING: $message');
  }

  static void logError(String message, {Object? error, StackTrace? stack}) {
    print('ERROR: $message - $error');
    FirebaseCrashlytics.instance.recordError(error, stack, reason: message);
  }
}