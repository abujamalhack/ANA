class AppConstants {
  // Agora – يتم استخدام Token Server فقط، لذا لا نحتاج App ID في الكود
  // لكن يمكن الاحتفاظ بقيمة افتراضية للاختبار (ستُستبدل بالتوكن)
  static const String agoraAppId = 'DUMMY_APP_ID'; // لا تستخدم في الإنتاج

  static const int maxRoomUsers = 50;
  static const int tokenExpirySeconds = 3600;
  static const int maxRetries = 3;
  static const Duration retryDelay = Duration(seconds: 2);
}