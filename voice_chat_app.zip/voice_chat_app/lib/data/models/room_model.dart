import 'package:equatable/equatable.dart';

enum UserRole { owner, moderator, user }

class RoomModel extends Equatable {
  final String roomId;
  final String roomName;
  final String creatorUid;
  final bool isPrivate;
  final Map<String, UserRole> participants;
  final List<String> raisedHands;
  final List<String> mutedUsers;
  final DateTime createdAt;
  final String? password;

  const RoomModel({
    required this.roomId,
    required this.roomName,
    required this.creatorUid,
    required this.isPrivate,
    required this.participants,
    required this.raisedHands,
    required this.mutedUsers,
    required this.createdAt,
    this.password,
  });

  Map<String, dynamic> toJson() => {
        'roomId': roomId,
        'roomName': roomName,
        'creatorUid': creatorUid,
        'isPrivate': isPrivate,
        'participants': participants.map((k, v) => MapEntry(k, v.name)),
        'raisedHands': raisedHands,
        'mutedUsers': mutedUsers,
        'createdAt': createdAt.toIso8601String(),
        'password': password,
      };

  factory RoomModel.fromJson(Map<String, dynamic> json) {
    final participantsMap = (json['participants'] as Map<String, dynamic>).map(
      (key, value) => MapEntry(key, UserRole.values.firstWhere((e) => e.name == value)),
    );
    return RoomModel(
      roomId: json['roomId'],
      roomName: json['roomName'],
      creatorUid: json['creatorUid'],
      isPrivate: json['isPrivate'],
      participants: participantsMap,
      raisedHands: List<String>.from(json['raisedHands'] ?? []),
      mutedUsers: List<String>.from(json['mutedUsers'] ?? []),
      createdAt: DateTime.parse(json['createdAt']),
      password: json['password'],
    );
  }

  RoomModel copyWith({
    String? roomId,
    String? roomName,
    String? creatorUid,
    bool? isPrivate,
    Map<String, UserRole>? participants,
    List<String>? raisedHands,
    List<String>? mutedUsers,
    DateTime? createdAt,
    String? password,
  }) {
    return RoomModel(
      roomId: roomId ?? this.roomId,
      roomName: roomName ?? this.roomName,
      creatorUid: creatorUid ?? this.creatorUid,
      isPrivate: isPrivate ?? this.isPrivate,
      participants: participants ?? this.participants,
      raisedHands: raisedHands ?? this.raisedHands,
      mutedUsers: mutedUsers ?? this.mutedUsers,
      createdAt: createdAt ?? this.createdAt,
      password: password ?? this.password,
    );
  }

  @override
  List<Object?> get props => [
        roomId,
        roomName,
        creatorUid,
        isPrivate,
        participants,
        raisedHands,
        mutedUsers,
        createdAt,
        password,
      ];
}