import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:voice_chat_app/core/utils/logger.dart';
import 'package:firebase_auth/firebase_auth.dart';

// Global navigator key for handling notification navigation
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

class NotificationService {
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;

  Future<void> initialize() async {
    // Request permission
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );
    if (settings.authorizationStatus != AuthorizationStatus.authorized) {
      Logger.logInfo('User declined or not granted notification permission');
      return;
    }

    // Get token
    final token = await _fcm.getToken();
    if (token != null) {
      await _saveToken(token);
    }

    // Listen for token refresh
    _fcm.onTokenRefresh.listen(_saveToken);

    // Handle foreground messages
    FirebaseMessaging.onMessage.listen(_handleForegroundMessage);
    FirebaseMessaging.onMessageOpenedApp.listen(_handleBackgroundTap);
  }

  Future<void> _saveToken(String token) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    final tokenDoc = FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('tokens')
        .doc(token);
    await tokenDoc.set({
      'token': token,
      'createdAt': FieldValue.serverTimestamp(),
      'platform': defaultTargetPlatform.toString(),
    });
  }

  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    Logger.logInfo('Foreground message: ${message.data}');
    // Optionally show local notification
  }

  void _handleBackgroundTap(RemoteMessage message) {
    Logger.logInfo('Message opened: ${message.data}');
    final roomId = message.data['roomId'];
    if (roomId != null && navigatorKey.currentContext != null) {
      navigatorKey.currentContext!.pushNamed('/room', arguments: roomId);
    }
  }

  Future<void> deleteToken(String token) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await FirebaseFirestore.instance
        .collection('users')
        .doc(user.uid)
        .collection('tokens')
        .doc(token)
        .delete();
  }
}