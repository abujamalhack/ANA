import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:voice_chat_app/data/models/user_model.dart';
import 'package:voice_chat_app/data/models/room_model.dart';

abstract class FirebaseService {
  // Auth
  Stream<User?> get authStateChanges;
  User? get currentUser;
  Future<UserCredential> signInWithEmail(String email, String password);
  Future<UserCredential> signUpWithEmail(String email, String password);
  Future<void> signOut();

  // Users
  Future<void> createUserDocument(UserModel user);
  Future<UserModel?> getUserDocument(String uid);
  Future<void> updateUserDocument(String uid, Map<String, dynamic> data);

  // Rooms
  Future<String> createRoom(RoomModel room);
  Future<RoomModel?> getRoom(String roomId);
  Stream<QuerySnapshot> getPublicRooms({int limit = 20, DocumentSnapshot? startAfter});
  
  // الدالة الجديدة للـ pagination (مرة واحدة)
  Future<({List<RoomModel> rooms, DocumentSnapshot? lastDoc})> getPublicRoomsPaginated({
    int limit = 20,
    DocumentSnapshot? startAfter,
  });

  Future<void> addParticipant(String roomId, String uid, UserRole role);
  Future<void> removeParticipant(String roomId, String uid);
  Future<void> updateRoomParticipants(String roomId, Map<String, UserRole> participants);
  Future<void> deleteRoom(String roomId);
  Stream<DocumentSnapshot> streamRoom(String roomId);
  Future<void> raiseHand(String roomId, String uid);
  Future<void> lowerHand(String roomId, String uid);
  Future<void> muteUserByModerator(String roomId, String uid);
  Future<void> unmuteUserByModerator(String roomId, String uid);
}

class FirebaseServiceImpl implements FirebaseService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Auth
  @override
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  @override
  User? get currentUser => _auth.currentUser;

  @override
  Future<UserCredential> signInWithEmail(String email, String password) async {
    return await _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  @override
  Future<UserCredential> signUpWithEmail(String email, String password) async {
    return await _auth.createUserWithEmailAndPassword(email: email, password: password);
  }

  @override
  Future<void> signOut() async {
    await _auth.signOut();
  }

  // Users
  @override
  Future<void> createUserDocument(UserModel user) async {
    await _firestore.collection('users').doc(user.uid).set(user.toJson());
  }

  @override
  Future<UserModel?> getUserDocument(String uid) async {
    final doc = await _firestore.collection('users').doc(uid).get();
    if (doc.exists) return UserModel.fromJson(doc.data()!);
    return null;
  }

  @override
  Future<void> updateUserDocument(String uid, Map<String, dynamic> data) async {
    await _firestore.collection('users').doc(uid).update(data);
  }

  // Rooms
  @override
  Future<String> createRoom(RoomModel room) async {
    final docRef = _firestore.collection('rooms').doc();
    final newRoom = room.copyWith(roomId: docRef.id);
    await docRef.set(newRoom.toJson());
    return docRef.id;
  }

  @override
  Future<RoomModel?> getRoom(String roomId) async {
    final doc = await _firestore.collection('rooms').doc(roomId).get();
    if (doc.exists) return RoomModel.fromJson(doc.data()!);
    return null;
  }

  @override
  Stream<QuerySnapshot> getPublicRooms({int limit = 20, DocumentSnapshot? startAfter}) {
    var query = _firestore
        .collection('rooms')
        .where('isPrivate', isEqualTo: false)
        .orderBy('createdAt', descending: true)
        .limit(limit);
    if (startAfter != null) query = query.startAfterDocument(startAfter);
    return query.snapshots();
  }

  // الدالة الجديدة: تجلب صفحة واحدة من الغرف العامة
  @override
  Future<({List<RoomModel> rooms, DocumentSnapshot? lastDoc})> getPublicRoomsPaginated({
    int limit = 20,
    DocumentSnapshot? startAfter,
  }) async {
    var query = _firestore
        .collection('rooms')
        .where('isPrivate', isEqualTo: false)
        .orderBy('createdAt', descending: true)
        .limit(limit);
    if (startAfter != null) query = query.startAfterDocument(startAfter);
    final snapshot = await query.get();
    final rooms = snapshot.docs
        .map((doc) => RoomModel.fromJson(doc.data() as Map<String, dynamic>))
        .toList();
    final lastDoc = snapshot.docs.isNotEmpty ? snapshot.docs.last : null;
    return (rooms: rooms, lastDoc: lastDoc);
  }

  @override
  Future<void> addParticipant(String roomId, String uid, UserRole role) async {
    await _firestore.collection('rooms').doc(roomId).update({
      'participants.$uid': role.name,
    });
  }

  @override
  Future<void> removeParticipant(String roomId, String uid) async {
    await _firestore.collection('rooms').doc(roomId).update({
      'participants.$uid': FieldValue.delete(),
    });
  }

  @override
  Future<void> updateRoomParticipants(String roomId, Map<String, UserRole> participants) async {
    final participantsMap = participants.map((k, v) => MapEntry(k, v.name));
    await _firestore.collection('rooms').doc(roomId).update({
      'participants': participantsMap,
    });
  }

  @override
  Future<void> deleteRoom(String roomId) async {
    await _firestore.collection('rooms').doc(roomId).delete();
  }

  @override
  Stream<DocumentSnapshot> streamRoom(String roomId) {
    return _firestore.collection('rooms').doc(roomId).snapshots();
  }

  @override
  Future<void> raiseHand(String roomId, String uid) async {
    await _firestore.collection('rooms').doc(roomId).update({
      'raisedHands': FieldValue.arrayUnion([uid]),
    });
  }

  @override
  Future<void> lowerHand(String roomId, String uid) async {
    await _firestore.collection('rooms').doc(roomId).update({
      'raisedHands': FieldValue.arrayRemove([uid]),
    });
  }

  @override
  Future<void> muteUserByModerator(String roomId, String uid) async {
    await _firestore.collection('rooms').doc(roomId).update({
      'mutedUsers': FieldValue.arrayUnion([uid]),
    });
  }

  @override
  Future<void> unmuteUserByModerator(String roomId, String uid) async {
    await _firestore.collection('rooms').doc(roomId).update({
      'mutedUsers': FieldValue.arrayRemove([uid]),
    });
  }
}