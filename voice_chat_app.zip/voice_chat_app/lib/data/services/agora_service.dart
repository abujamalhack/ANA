import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:async';

class AgoraService {
  // 🔑 App ID الخاص بك من Agora
  static const String _appId = "5422d2a650964d509df6e05f01d06242";

  static RtcEngine? _engine;
  static String? _currentChannel;
  static int? _currentUid;

  // Streams للتواصل مع واجهة المستخدم
  static final _userJoinedStream = StreamController<int>.broadcast();
  static final _userLeftStream = StreamController<int>.broadcast();
  static final _errorStream = StreamController<String>.broadcast();
  static final _connectionStateStream = StreamController<ConnectionState>.broadcast();
  static final _audioVolumeStream = StreamController<Map<int, int>>.broadcast();

  static Stream<int> get onUserJoined => _userJoinedStream.stream;
  static Stream<int> get onUserLeft => _userLeftStream.stream;
  static Stream<String> get onError => _errorStream.stream;
  static Stream<ConnectionState> get onConnectionState => _connectionStateStream.stream;
  static Stream<Map<int, int>> get onAudioVolume => _audioVolumeStream.stream;

  // تهيئة المحرك وطلب الصلاحيات
  static Future<bool> initialize() async {
    // طلب إذن الميكروفون
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _errorStream.add("Microphone permission denied");
      return false;
    }

    // إنشاء وتهيئة محرك Agora
    _engine = createAgoraRtcEngine();
    await _engine!.initialize(RtcEngineContext(appId: _appId));

    // تفعيل الصوت
    await _engine!.enableAudio();

    // إعدادات جودة الصوت (محسّنة للمكالمات)
    await _engine!.setAudioProfile(
      AudioProfile.musicHighQuality,
      AudioScenario.gameStreaming,
    );

    // إعدادات متقدمة لتقليل الضوضاء والصدى
    await _engine!.setParameters('{"che.audio.aec.enable": true}'); // إلغاء الصدى
    await _engine!.setParameters('{"che.audio.ans.enable": true}'); // تقليل الضوضاء
    await _engine!.setParameters('{"che.audio.agc.enable": true}'); // ضبط تلقائي للكسب

    // تفعيل مؤشر مستوى الصوت
    await _engine!.enableAudioVolumeIndication(200, 3, true);

    // تسجيل معالجات الأحداث
    _engine!.registerEventHandler(
      RtcEngineEventHandler(
        onUserJoined: (connection, remoteUid, elapsed) {
          _userJoinedStream.add(remoteUid);
        },
        onUserOffline: (connection, remoteUid, reason) {
          _userLeftStream.add(remoteUid);
        },
        onError: (err, msg) {
          _errorStream.add("Error $err: $msg");
        },
        onConnectionStateChanged: (connection, state, reason) {
          _connectionStateStream.add(state);
        },
        onAudioVolumeIndication: (speakers, totalVolume) {
          final volumeMap = <int, int>{};
          for (var speaker in speakers) {
            volumeMap[speaker.uid] = speaker.volume;
          }
          _audioVolumeStream.add(volumeMap);
        },
      ),
    );

    return true;
  }

  // الانضمام إلى قناة صوتية
  static Future<void> joinChannel({
    required String token,
    required String channelName,
    int uid = 0,
  }) async {
    if (_engine == null) {
      _errorStream.add("Engine not initialized");
      return;
    }

    _currentChannel = channelName;
    _currentUid = uid;

    await _engine!.joinChannel(
      token: token,
      channelId: channelName,
      uid: uid,
      options: ChannelMediaOptions(
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
        publishMicrophoneTrack: true,
        publishCameraTrack: false,
        autoSubscribeAudio: true,
      ),
    );
  }

  // مغادرة القناة
  static Future<void> leaveChannel() async {
    if (_engine == null) return;
    await _engine!.leaveChannel();
    _currentChannel = null;
    _currentUid = null;
  }

  // كتم / فتح المايك
  static Future<void> muteLocalAudio(bool mute) async {
    await _engine?.muteLocalAudioStream(mute);
  }

  // تفعيل / إلغاء مكبر الصوت
  static Future<void> enableSpeakerphone(bool enable) async {
    await _engine?.setEnableSpeakerphone(enable);
  }

  // تحرير الموارد
  static Future<void> release() async {
    await _engine?.leaveChannel();
    await _engine?.release();
    _engine = null;
    _currentChannel = null;
    _currentUid = null;
  }

  // التخلص من StreamControllers
  static void dispose() {
    _userJoinedStream.close();
    _userLeftStream.close();
    _errorStream.close();
    _connectionStateStream.close();
    _audioVolumeStream.close();
  }
}