import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:async';

class AgoraService {
  static AgoraRtcEngine? _engine;
  static String? _currentChannel;
  static int? _currentUid;

  static final _userJoinedStream = StreamController<int>.broadcast();
  static final _userLeftStream = StreamController<int>.broadcast();
  static final _errorStream = StreamController<String>.broadcast();
  static final _connectionStateStream = StreamController<ConnectionState>.broadcast();

  static Stream<int> get onUserJoined => _userJoinedStream.stream;
  static Stream<int> get onUserLeft => _userLeftStream.stream;
  static Stream<String> get onError => _errorStream.stream;
  static Stream<ConnectionState> get onConnectionState => _connectionStateStream.stream;

  static Future<bool> initialize(String appId) async {
    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      _errorStream.add("Microphone permission denied");
      return false;
    }

    _engine = createAgoraRtcEngine();
    await _engine!.initialize(RtcEngineContext(appId: appId));

    await _engine!.enableAudio();
    await _engine!.setAudioProfile(
      AudioProfile.musicHighQuality,
      AudioScenario.gameStreaming,
    );
    // إعدادات متقدمة لجودة الصوت
    await _engine!.setParameters('{"che.audio.aec.enable": true}');
    await _engine!.setParameters('{"che.audio.ans.enable": true}');
    await _engine!.setParameters('{"che.audio.agc.enable": true}');

    _engine!.registerEventHandler(
      RtcEngineEventHandler(
        onUserJoined: (connection, remoteUid, elapsed) {
          _userJoinedStream.add(remoteUid);
        },
        onUserOffline: (connection, remoteUid, reason) {
          _userLeftStream.add(remoteUid);
        },
        onError: (err, msg) {
          _errorStream.add("Error $err: $msg");
        },
        onConnectionStateChanged: (connection, state, reason) {
          _connectionStateStream.add(state);
        },
      ),
    );
    return true;
  }

  static Future<bool> initialize(String appId) async {
  final status = await Permission.microphone.request();
  if (!status.isGranted) {
    _errorStream.add("Microphone permission denied");
    return false;
  }

  _engine = createAgoraRtcEngine();
  await _engine!.initialize(RtcEngineContext(appId: appId));

  await _engine!.enableAudio();
  await _engine!.setAudioProfile(
    AudioProfile.musicHighQuality,
    AudioScenario.gameStreaming,
  );
  // إعدادات متقدمة لتحسين جودة الصوت وتقليل الضوضاء
  await _engine!.setParameters('{"che.audio.aec.enable": true}');
  await _engine!.setParameters('{"che.audio.ans.enable": true}');
  await _engine!.setParameters('{"che.audio.agc.enable": true}');
  
  // تمكين إشارة مستوى الصوت
  await _engine!.enableAudioVolumeIndication(200, 3, true);

  _engine!.registerEventHandler(
    RtcEngineEventHandler(
      onUserJoined: (connection, remoteUid, elapsed) {
        _userJoinedStream.add(remoteUid);
      },
      onUserOffline: (connection, remoteUid, reason) {
        _userLeftStream.add(remoteUid);
      },
      onError: (err, msg) {
        _errorStream.add("Error $err: $msg");
      },
      onConnectionStateChanged: (connection, state, reason) {
        _connectionStateStream.add(state);
      },
    ),
  );
  return true;
}