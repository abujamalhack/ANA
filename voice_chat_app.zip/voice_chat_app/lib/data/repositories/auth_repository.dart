import 'package:voice_chat_app/data/models/user_model.dart';
import 'package:voice_chat_app/data/services/firebase_service.dart';
import 'package:firebase_auth/firebase_auth.dart';

abstract class AuthRepository {
  Stream<UserModel?> get authState;
  UserModel? get currentUser;
  Future<UserModel> loginWithEmail(String email, String password);
  Future<UserModel> registerWithEmail(String email, String password, String displayName);
  Future<void> logout();
}

class AuthRepositoryImpl implements AuthRepository {
  final FirebaseService _firebaseService;

  AuthRepositoryImpl(this._firebaseService);

  @override
  Stream<UserModel?> get authState {
    return _firebaseService.authStateChanges.map((firebaseUser) {
      if (firebaseUser == null) return null;
      return UserModel(
        uid: firebaseUser.uid,
        email: firebaseUser.email ?? '',
        displayName: firebaseUser.displayName,
        photoUrl: firebaseUser.photoURL,
        createdAt: DateTime.now(),
      );
    });
  }

  @override
  UserModel? get currentUser {
    final user = _firebaseService.currentUser;
    if (user == null) return null;
    return UserModel(
      uid: user.uid,
      email: user.email ?? '',
      displayName: user.displayName,
      photoUrl: user.photoURL,
      createdAt: DateTime.now(),
    );
  }

  @override
  Future<UserModel> loginWithEmail(String email, String password) async {
    final credential = await _firebaseService.signInWithEmail(email, password);
    final firebaseUser = credential.user!;
    final userDoc = await _firebaseService.getUserDocument(firebaseUser.uid);
    if (userDoc != null) return userDoc;
    final newUser = UserModel(
      uid: firebaseUser.uid,
      email: firebaseUser.email ?? '',
      displayName: firebaseUser.displayName,
      photoUrl: firebaseUser.photoURL,
      createdAt: DateTime.now(),
    );
    await _firebaseService.createUserDocument(newUser);
    return newUser;
  }

  @override
  Future<UserModel> registerWithEmail(String email, String password, String displayName) async {
    final credential = await _firebaseService.signUpWithEmail(email, password);
    final firebaseUser = credential.user!;
    await firebaseUser.updateDisplayName(displayName);
    await firebaseUser.reload();
    final updatedUser = _firebaseService.currentUser!;
    final userModel = UserModel(
      uid: updatedUser.uid,
      email: updatedUser.email ?? '',
      displayName: displayName,
      photoUrl: updatedUser.photoURL,
      createdAt: DateTime.now(),
    );
    await _firebaseService.createUserDocument(userModel);
    return userModel;
  }

  @override
  Future<void> logout() async {
    await _firebaseService.signOut();
  }
}