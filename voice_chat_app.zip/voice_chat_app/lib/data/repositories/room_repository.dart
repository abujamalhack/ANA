import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:voice_chat_app/data/models/room_model.dart';
import 'package:voice_chat_app/data/services/firebase_service.dart';

abstract class RoomRepository {
  Future<String> createRoom(RoomModel room);
  Future<void> joinRoom(String roomId, String userId);
  Future<void> leaveRoom(String roomId, String userId);
  Stream<List<RoomModel>> getPublicRooms({int limit = 20, DocumentSnapshot? startAfter});
  Stream<RoomModel?> streamRoom(String roomId);
  Future<RoomModel?> getRoom(String roomId);
  Future<void> deleteRoom(String roomId);
  Future<void> raiseHand(String roomId, String uid);
  Future<void> lowerHand(String roomId, String uid);
  Future<void> muteUser(String roomId, String uid);
  Future<void> unmuteUser(String roomId, String uid);
  Future<void> removeUser(String roomId, String uid);
  Future<void> setModerator(String roomId, String uid, bool isModerator);
}

class RoomRepositoryImpl implements RoomRepository {
  final FirebaseService _firebaseService;

  RoomRepositoryImpl(this._firebaseService);

  @override
  Future<String> createRoom(RoomModel room) async {
    return await _firebaseService.createRoom(room);
  }

  @override
  Future<void> joinRoom(String roomId, String userId) async {
    final room = await _firebaseService.getRoom(roomId);
    if (room != null && !room.participants.containsKey(userId)) {
      await _firebaseService.addParticipant(roomId, userId, UserRole.user);
    }
  }

  @override
  Future<void> leaveRoom(String roomId, String userId) async {
    await _firebaseService.removeParticipant(roomId, userId);
    // Remove from other lists
    await _firebaseService.lowerHand(roomId, userId);
    await _firebaseService.unmuteUserByModerator(roomId, userId);
  }

  @override
  Stream<List<RoomModel>> getPublicRooms({int limit = 20, DocumentSnapshot? startAfter}) {
    return _firebaseService.getPublicRooms(limit: limit, startAfter: startAfter).map((snapshot) {
      return snapshot.docs.map((doc) => RoomModel.fromJson(doc.data() as Map<String, dynamic>)).toList();
    });
  }

  @override
  Stream<RoomModel?> streamRoom(String roomId) {
    return _firebaseService.streamRoom(roomId).map((doc) {
      if (doc.exists) return RoomModel.fromJson(doc.data() as Map<String, dynamic>);
      return null;
    });
  }

  @override
  Future<RoomModel?> getRoom(String roomId) async {
    return await _firebaseService.getRoom(roomId);
  }

  @override
  Future<void> deleteRoom(String roomId) async {
    await _firebaseService.deleteRoom(roomId);
  }

  @override
  Future<void> raiseHand(String roomId, String uid) async {
    await _firebaseService.raiseHand(roomId, uid);
  }

  @override
  Future<void> lowerHand(String roomId, String uid) async {
    await _firebaseService.lowerHand(roomId, uid);
  }

  @override
  Future<void> muteUser(String roomId, String uid) async {
    await _firebaseService.muteUserByModerator(roomId, uid);
  }

  @override
  Future<void> unmuteUser(String roomId, String uid) async {
    await _firebaseService.unmuteUserByModerator(roomId, uid);
  }

  @override
  Future<void> removeUser(String roomId, String uid) async {
    final room = await _firebaseService.getRoom(roomId);
    if (room == null) return;
    final newParticipants = Map<String, UserRole>.from(room.participants);
    newParticipants.remove(uid);
    await _firebaseService.updateRoomParticipants(roomId, newParticipants);
    await _firebaseService.lowerHand(roomId, uid);
    await _firebaseService.unmuteUserByModerator(roomId, uid);
  }

  @override
  Future<void> setModerator(String roomId, String uid, bool isModerator) async {
    final role = isModerator ? UserRole.moderator : UserRole.user;
    await _firebaseService.addParticipant(roomId, uid, role);
  }
}