const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { RtcTokenBuilder, RtcRole } = require('agora-access-token');

admin.initializeApp();

// Helper: Get all tokens for a list of users
async function getUserTokens(uids) {
  const tokens = [];
  for (const uid of uids) {
    const snapshot = await admin.firestore()
      .collection('users')
      .doc(uid)
      .collection('tokens')
      .get();
    snapshot.forEach(doc => {
      if (doc.data().token) tokens.push(doc.data().token);
    });
  }
  return [...new Set(tokens)];
}

// Send notification to multiple users
async function sendNotificationToUsers(uids, payload) {
  const tokens = await getUserTokens(uids);
  if (tokens.length === 0) return;

  const response = await admin.messaging().sendEachForMulticast({
    tokens,
    ...payload,
  });

  // Remove invalid tokens
  if (response.failureCount > 0) {
    const failedTokens = [];
    response.responses.forEach((resp, idx) => {
      if (!resp.success) failedTokens.push(tokens[idx]);
    });
    for (const token of failedTokens) {
      const snapshot = await admin.firestore()
        .collectionGroup('tokens')
        .where('token', '==', token)
        .get();
      const batch = admin.firestore().batch();
      snapshot.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
    }
  }
}

// 1. Generate Agora Token
exports.generateToken = functions.https.onCall(async (data, context) => {
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'User must be logged in');
  }
  const { channelName, uid } = data;
  if (!channelName || uid === undefined) {
    throw new functions.https.HttpsError('invalid-argument', 'Missing parameters');
  }

  const APP_ID = functions.config().agora.app_id;
  const APP_CERTIFICATE = functions.config().agora.app_certificate;
  if (!APP_ID || !APP_CERTIFICATE) {
    throw new functions.https.HttpsError('internal', 'Agora credentials not configured');
  }

  const role = RtcRole.PUBLISHER;
  const expireTime = 3600; // 1 hour
  const currentTimestamp = Math.floor(Date.now() / 1000);
  const privilegeExpiredTs = currentTimestamp + expireTime;

  const token = RtcTokenBuilder.buildTokenWithUid(
    APP_ID,
    APP_CERTIFICATE,
    channelName,
    uid,
    role,
    privilegeExpiredTs
  );

  return { token, expireTime };
});

// 2. On Raise Hand (with null-safe handling)
exports.onRaiseHand = functions.firestore
  .document('rooms/{roomId}')
  .onUpdate(async (change, context) => {
    const before = change.before.data();
    const after = change.after.data();
    const beforeHands = before.raisedHands || [];
    const afterHands = after.raisedHands || [];
    const addedHands = afterHands.filter(h => !beforeHands.includes(h));
    if (addedHands.length === 0) return null;

    const raisedUid = addedHands[0];
    const moderators = Object.keys(after.participants)
      .filter(uid => after.participants[uid] === 'moderator' || after.participants[uid] === 'owner');

    const payload = {
      notification: {
        title: '🙋‍♂️ Hand Raised',
        body: `User ${raisedUid.substring(0,6)} wants to speak`,
      },
      data: {
        roomId: context.params.roomId,
        uid: raisedUid,
        type: 'hand_raised',
      },
    };
    await sendNotificationToUsers(moderators, payload);
    return null;
  });

// 3. On User Join/Leave
exports.onUserJoinLeave = functions.firestore
  .document('rooms/{roomId}')
  .onUpdate(async (change, context) => {
    const before = change.before.data();
    const after = change.after.data();
    const beforeParticipants = Object.keys(before.participants || {});
    const afterParticipants = Object.keys(after.participants || {});
    const joined = afterParticipants.filter(uid => !beforeParticipants.includes(uid));
    const left = beforeParticipants.filter(uid => !afterParticipants.includes(uid));

    const moderators = Object.keys(after.participants || {})
      .filter(uid => after.participants[uid] === 'moderator' || after.participants[uid] === 'owner');

    if (joined.length > 0) {
      const payload = {
        notification: {
          title: '🔊 User Joined',
          body: `${joined[0].substring(0,6)} joined the room`,
        },
        data: { roomId: context.params.roomId, uid: joined[0], type: 'user_joined' },
      };
      await sendNotificationToUsers(moderators, payload);
    }
    if (left.length > 0) {
      const payload = {
        notification: {
          title: '👋 User Left',
          body: `${left[0].substring(0,6)} left the room`,
        },
        data: { roomId: context.params.roomId, uid: left[0], type: 'user_left' },
      };
      await sendNotificationToUsers(moderators, payload);
    }
    return null;
  });

// 4. Set Moderator (callable, secure)
exports.setModerator = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Authentication required');
  const { roomId, targetUid, isModerator } = data;
  const uid = context.auth.uid;

  const roomRef = admin.firestore().collection('rooms').doc(roomId);
  const roomDoc = await roomRef.get();
  if (!roomDoc.exists) throw new functions.https.HttpsError('not-found', 'Room not found');
  const room = roomDoc.data();

  // Only owner can set moderators
  if (room.participants[uid] !== 'owner') {
    throw new functions.https.HttpsError('permission-denied', 'Only room owner can set moderators');
  }
  // Cannot change owner role
  if (targetUid === room.creatorUid) {
    throw new functions.https.HttpsError('invalid-argument', 'Cannot change owner role');
  }

  const newRole = isModerator ? 'moderator' : 'user';
  await roomRef.update({
    [`participants.${targetUid}`]: newRole,
  });

  // Send notification to target user
  const targetTokens = await getUserTokens([targetUid]);
  if (targetTokens.length > 0) {
    const payload = {
      notification: {
        title: isModerator ? '🎖️ You are now a moderator' : '📢 You are no longer a moderator',
        body: `In room ${room.roomName}`,
      },
      data: { roomId, type: 'role_changed' },
    };
    await admin.messaging().sendEachForMulticast({ tokens: targetTokens, ...payload });
  }

  return { success: true };
});

// 5. Remove User (callable, secure)
exports.removeUser = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Authentication required');
  const { roomId, targetUid } = data;
  const uid = context.auth.uid;

  const roomRef = admin.firestore().collection('rooms').doc(roomId);
  const roomDoc = await roomRef.get();
  if (!roomDoc.exists) throw new functions.https.HttpsError('not-found', 'Room not found');
  const room = roomDoc.data();

  const callerRole = room.participants[uid];
  if (callerRole !== 'owner' && callerRole !== 'moderator') {
    throw new functions.https.HttpsError('permission-denied', 'Not authorized to remove users');
  }
  if (targetUid === room.creatorUid) {
    throw new functions.https.HttpsError('invalid-argument', 'Cannot remove room owner');
  }

  await roomRef.update({
    [`participants.${targetUid}`]: admin.firestore.FieldValue.delete(),
  });
  await roomRef.update({
    raisedHands: admin.firestore.FieldValue.arrayRemove(targetUid),
    mutedUsers: admin.firestore.FieldValue.arrayRemove(targetUid),
  });

  return { success: true };
});